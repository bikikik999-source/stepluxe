# StepLuxe Srbija

Srpska verzija StepLuxe prodavnice:
- sve cene su u RSD
- interfejs je na srpskom
- poručivanje je namenjeno samo adresama u Srbiji
- admin panel je na `/admin.html`
- admin šifra: `stepluxemiksa`
- podržano je više slika po proizvodu

Važno: ovo je i dalje demo/prototip. Proizvodi i porudžbine se čuvaju u browser localStorage-u. Za pravu prodavnicu treba dodati bazu podataka, sigurnu autentifikaciju admina i pravi sistem plaćanja/porudžbina.
